/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/Recommend")
@MultipartConfig(maxFileSize = 1073741824)
public class Recommend extends HttpServlet {

    private String dbURL = "jdbc:mysql://localhost:3306/temple";
    private String dbUser = "root";
    private String dbPass = "root";

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String name = request.getParameter("name");
        String dob = request.getParameter("dob");
        String document_type = request.getParameter("document");
//        String document = request.getParameter("file-upload");
        String proofno = request.getParameter("proof-number");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        // System.out.println("User Recommend :" + gen + age + marital + edu + interest + content);
        InputStream inputStream = null;
        Part filePart = request.getPart("file-upload");
        if (filePart != null) {

            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());


            inputStream = filePart.getInputStream();

        }

        Connection conn = null;
        String message = null;
        try {

            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

            //Checking if AID is Available Already
            String sql = "";
            PreparedStatement statement;

            sql = "INSERT INTO volunteerapply(name,dob,document_type,document,proofno,email,mobile) values (?, ?, ?, ?, ?, ?,?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, dob);
            statement.setString(3, document_type);
            statement.setString(5, proofno);
            statement.setString(6, email);
            statement.setString(7, mobile);

            if (inputStream != null) {
                statement.setBlob(4, inputStream);
            }


            //  statement.setString(1, bio);




            int row = statement.executeUpdate();
            if (row > 0) {

                System.out.println("image upload sucess");
                response.sendRedirect("userhome.jsp?msg=success,");
            } else {
                response.sendRedirect("userhome.jsp?msg=Failed");

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}