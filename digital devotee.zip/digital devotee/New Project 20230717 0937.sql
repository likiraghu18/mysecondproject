-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.13


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema temple
--

CREATE DATABASE IF NOT EXISTS temple;
USE temple;

--
-- Definition of table `activevolunteers`
--

DROP TABLE IF EXISTS `activevolunteers`;
CREATE TABLE `activevolunteers` (
  `name` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `document` blob,
  `proofno` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activevolunteers`
--

/*!40000 ALTER TABLE `activevolunteers` DISABLE KEYS */;
INSERT INTO `activevolunteers` (`name`,`dob`,`document_type`,`document`,`proofno`,`email`,`mobile`) VALUES 
 ('Raghu','2023-07-13','null',0x646F63756D656E74,'12345','ragraghu18@gmail.com','9964929484'),
 ('Raghu','2023-07-13','null',0x646F63756D656E74,'12345','ragraghu18@gmail.com','9964929484'),
 ('Likith BU','2023-07-14','null',0x646F63756D656E74,'22341','likiraghu18@gmail.com','9987098343'),
 ('bravo','2023-07-06','id-card',0x646F63756D656E74,'22341','harshithabu56@gmail.com','9987098343'),
 ('Umashankar ','1980-11-14','driver-license',0x646F63756D656E74,'12345','umashankarbm@gmail.com','9964929484'),
 ('Likith BU','2023-07-04','driver-license',0x646F63756D656E74,'22341','cs@gmail.com','7899694249');
/*!40000 ALTER TABLE `activevolunteers` ENABLE KEYS */;


--
-- Definition of table `adminlogin`
--

DROP TABLE IF EXISTS `adminlogin`;
CREATE TABLE `adminlogin` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

/*!40000 ALTER TABLE `adminlogin` DISABLE KEYS */;
INSERT INTO `adminlogin` (`username`,`password`) VALUES 
 ('admin','admin');
/*!40000 ALTER TABLE `adminlogin` ENABLE KEYS */;


--
-- Definition of table `bookedsevas`
--

DROP TABLE IF EXISTS `bookedsevas`;
CREATE TABLE `bookedsevas` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `sevaname` varchar(50) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `sevaId` varchar(50) DEFAULT NULL,
  `datetime` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookedsevas`
--

/*!40000 ALTER TABLE `bookedsevas` DISABLE KEYS */;
INSERT INTO `bookedsevas` (`name`,`email`,`sevaname`,`amount`,`sevaId`,`datetime`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:05:38 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:05:38 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:05:38 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:05:38 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:05:38 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:09:03 PM'),
 ('Likith BU','likiraghu18@gmail.com','Serva seva','300','','7/13/2023, 9:14:10 PM');
INSERT INTO `bookedsevas` (`name`,`email`,`sevaname`,`amount`,`sevaId`,`datetime`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','Kanaka Kavacha samarpana','4000','1612018','7/13/2023, 9:19:16 PM'),
 ('Likith BU','likiraghu18@gmail.com','Panchamrutam','100','2408404','7/13/2023, 9:22:19 PM'),
 ('Likith BU','likiraghu18@gmail.com','ksheerabhishekam','70','1230482','7/14/2023, 8:52:24 AM'),
 ('Likith BU','likiraghu18@gmail.com','Anna dhana','10000','6851202','7/16/2023, 1:59:31 PM'),
 ('Likith BU','likiraghu18@gmail.com','Anna dhana','10000','5848893','7/16/2023, 2:02:19 PM'),
 ('Likith BU','likiraghu18@gmail.com','Anna dhana','10000','1163808','7/16/2023, 3:58:45 PM');
/*!40000 ALTER TABLE `bookedsevas` ENABLE KEYS */;


--
-- Definition of table `currentbookings`
--

DROP TABLE IF EXISTS `currentbookings`;
CREATE TABLE `currentbookings` (
  `roomno` varchar(20) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `checkDT` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currentbookings`
--

/*!40000 ALTER TABLE `currentbookings` DISABLE KEYS */;
INSERT INTO `currentbookings` (`roomno`,`price`,`name`,`email`,`mobile`,`checkDT`) VALUES 
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-11T19:00'),
 ('101','150','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-26T09:21'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-19T20:02');
/*!40000 ALTER TABLE `currentbookings` ENABLE KEYS */;


--
-- Definition of table `dcurrentbookings`
--

DROP TABLE IF EXISTS `dcurrentbookings`;
CREATE TABLE `dcurrentbookings` (
  `roomno` varchar(20) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `checkinDT` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dcurrentbookings`
--

/*!40000 ALTER TABLE `dcurrentbookings` DISABLE KEYS */;
INSERT INTO `dcurrentbookings` (`roomno`,`price`,`name`,`email`,`mobile`,`checkinDT`) VALUES 
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-11T19:00'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-19T20:02'),
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-06T20:02'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-30T20:06'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-20T20:09'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-12T20:09'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-13T20:10'),
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-18T20:12'),
 ('104','1300','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-18T20:24'),
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-17T20:33'),
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-21T20:34'),
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-19T20:36');
INSERT INTO `dcurrentbookings` (`roomno`,`price`,`name`,`email`,`mobile`,`checkinDT`) VALUES 
 ('100','700','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-05T10:36'),
 ('101','150','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-26T09:21'),
 ('101','150','Likith BU','likiraghu18@gmail.com','7899694249','2023-07-20T09:25'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7892762927','2023-07-20T18:48'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7892762927','2023-07-20T18:48'),
 ('102','950','Likith BU','likiraghu18@gmail.com','7892762927','2023-07-20T18:48');
/*!40000 ALTER TABLE `dcurrentbookings` ENABLE KEYS */;


--
-- Definition of table `ddonations`
--

DROP TABLE IF EXISTS `ddonations`;
CREATE TABLE `ddonations` (
  `name` varchar(50) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `transactionId` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ddonations`
--

/*!40000 ALTER TABLE `ddonations` DISABLE KEYS */;
INSERT INTO `ddonations` (`name`,`amount`,`datetime`,`mobile`,`email`,`note`,`transactionId`) VALUES 
 ('Veda','2000','7/11/2023, 4:56:26 PM','9964929484','vedavathi@gmail.com','','1316817'),
 ('null','null','null','null','null','null','null'),
 ('varun','1000','7/12/2023, 10:36:13 AM','7899694249','varun@gmail.com','','4882170'),
 ('Raghu','70','7/12/2023, 2:00:15 PM','9987098944','ragraghu18@gmail.com','','2111709'),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com','','2734257'),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com','','2734257'),
 ('babu','100','7/13/2023, 7:17:35 PM','7765487552','babuasasashhsahhjashs@gmail.com','','2734257');
/*!40000 ALTER TABLE `ddonations` ENABLE KEYS */;


--
-- Definition of table `donations`
--

DROP TABLE IF EXISTS `donations`;
CREATE TABLE `donations` (
  `name` varchar(50) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `datetime` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donations`
--

/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` (`name`,`amount`,`datetime`,`mobile`,`email`,`note`) VALUES 
 ('Raghu','100','7/4/2023, 10:31:05 PM','9964929484','ragraghu18@gmail.com',''),
 ('Likith BU','100','7/8/2023, 8:45:39 AM','9908989742','ragraghu18@gmail.com',''),
 ('Raghu','100','7/8/2023, 8:48:20 AM','7892762927','darshan@gmail.com',''),
 ('Likith BU','100','7/8/2023, 8:48:41 AM','9987098343','harshithabu56@gmail.com',''),
 ('Raghu','100','7/10/2023, 9:16:07 PM','9987098944','darshan@gmail.com',''),
 ('bravo','1000','7/11/2023, 3:02:03 PM','9964929484','bravo@gmail.com',''),
 ('bravo','1000','7/11/2023, 3:02:03 PM','9964929484','bravo@gmail.com',''),
 ('Likith BU','500','7/11/2023, 2:53:08 PM','9964929484','likiraghu18@gmail.com',''),
 ('Veda','2000','7/11/2023, 4:56:26 PM','9964929484','vedavathi@gmail.com',''),
 ('varun','1000','7/12/2023, 10:36:13 AM','7899694249','varun@gmail.com',''),
 ('Raghu','70','7/12/2023, 2:00:15 PM','9987098944','ragraghu18@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com','');
INSERT INTO `donations` (`name`,`amount`,`datetime`,`mobile`,`email`,`note`) VALUES 
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com',''),
 ('babu','100','7/13/2023, 7:16:18 PM','7765487552','babus@gmail.com','');
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;


--
-- Definition of table `dprasadam`
--

DROP TABLE IF EXISTS `dprasadam`;
CREATE TABLE `dprasadam` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `prasadamname` varchar(50) DEFAULT NULL,
  `rate` varchar(50) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `totalamount` varchar(50) DEFAULT NULL,
  `orderId` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dprasadam`
--

/*!40000 ALTER TABLE `dprasadam` DISABLE KEYS */;
INSERT INTO `dprasadam` (`name`,`email`,`prasadamname`,`rate`,`quantity`,`totalamount`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','2','50',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','3','75',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','3','75',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','3','75',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','5','125',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','5','125',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','5','125',''),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','10','250','7536178'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','2','50','6448156'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','2060716'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','1132699'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','1711479'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','1711479');
INSERT INTO `dprasadam` (`name`,`email`,`prasadamname`,`rate`,`quantity`,`totalamount`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','1711479'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','1','25','9059079'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','8','200','9658484'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','3','75','5147296'),
 ('Likith BU','likiraghu18@gmail.com','Parimala prasadam','25','2','50','7986416');
/*!40000 ALTER TABLE `dprasadam` ENABLE KEYS */;


--
-- Definition of table `prasadam`
--

DROP TABLE IF EXISTS `prasadam`;
CREATE TABLE `prasadam` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `totalamount` varchar(50) DEFAULT NULL,
  `datetime` varchar(400) DEFAULT NULL,
  `orderId` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prasadam`
--

/*!40000 ALTER TABLE `prasadam` DISABLE KEYS */;
INSERT INTO `prasadam` (`name`,`email`,`quantity`,`totalamount`,`datetime`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:23:51 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:25:36 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:27:23 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:27:23 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:29:40 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:32:44 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:33:48 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:34:18 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:40:41 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:43:19 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:47:56 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:49:50 PM','null');
INSERT INTO `prasadam` (`name`,`email`,`quantity`,`totalamount`,`datetime`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:50:54 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:50:54 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','25','7/13/2023, 5:53:58 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','null','200','7/13/2023, 5:56:47 PM','null'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484');
INSERT INTO `prasadam` (`name`,`email`,`quantity`,`totalamount`,`datetime`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484');
INSERT INTO `prasadam` (`name`,`email`,`quantity`,`totalamount`,`datetime`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484');
INSERT INTO `prasadam` (`name`,`email`,`quantity`,`totalamount`,`datetime`,`orderId`) VALUES 
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','8','200','7/13/2023, 6:04:38 PM','9658484'),
 ('Likith BU','likiraghu18@gmail.com','3','75','7/13/2023, 6:57:41 PM','5147296');
/*!40000 ALTER TABLE `prasadam` ENABLE KEYS */;


--
-- Definition of table `roomdetails`
--

DROP TABLE IF EXISTS `roomdetails`;
CREATE TABLE `roomdetails` (
  `roomno` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `prize` varchar(50) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roomdetails`
--

/*!40000 ALTER TABLE `roomdetails` DISABLE KEYS */;
INSERT INTO `roomdetails` (`roomno`,`description`,`prize`,`status`) VALUES 
 ('100','2beds, 1fan with AC','700','Booked'),
 ('101','1beds','150','Booked'),
 ('102','2beds, 1fan with AC with tv','950','Booked'),
 ('104','fully furnished room','1300','Available'),
 ('102','2beds, 1fan with AC with tv','900','Booked');
/*!40000 ALTER TABLE `roomdetails` ENABLE KEYS */;


--
-- Definition of table `sevas`
--

DROP TABLE IF EXISTS `sevas`;
CREATE TABLE `sevas` (
  `sevaname` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sevas`
--

/*!40000 ALTER TABLE `sevas` DISABLE KEYS */;
INSERT INTO `sevas` (`sevaname`,`description`,`amount`,`time`) VALUES 
 ('Anna dhana','provid food to 700 devotees','10000','06:00'),
 ('ksheerabhishekam','Abhishekam to god with milk','70','07:00'),
 ('Archana sahita hastodaka','archana and  hastodaka seva to god','80','06:30'),
 ('Panchamrutam','Panchamrutam abhisheka to god','100','07:30'),
 ('Phala panchamruta','panchamruta(with fruits) to god','200','08:00'),
 ('Kanaka Kavacha samarpana','Gold kavacha alankara to god','4000','08:00'),
 ('Rathosavam','wooden chariot seva','1500','19:00'),
 ('Suvarna rathotsavam','Gold chariot seva','7000','19:30'),
 ('Navarathna rathotsavam','chariot studded with precious gems','6000','08:00'),
 ('Serva seva','general seva to god','300','06:30'),
 ('Taila nanda deepam','oil lamp in garbha gudi(1 month)','300','06:00');
/*!40000 ALTER TABLE `sevas` ENABLE KEYS */;


--
-- Definition of table `signup`
--

DROP TABLE IF EXISTS `signup`;
CREATE TABLE `signup` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` (`name`,`email`,`dob`,`mobile`,`password`) VALUES 
 ('Lalith','seervilalith2202@gmail.com','2003-01-28','9844089299','1234'),
 ('Likith BU','likiraghu18@gmail.com','2011-02-01','7892762927','1234');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;


--
-- Definition of table `usercomplaints`
--

DROP TABLE IF EXISTS `usercomplaints`;
CREATE TABLE `usercomplaints` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `complaint` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usercomplaints`
--

/*!40000 ALTER TABLE `usercomplaints` DISABLE KEYS */;
INSERT INTO `usercomplaints` (`name`,`email`,`complaint`) VALUES 
 ('Darshan','darshan@gmail.com','server problems'),
 ('Raghu','ragraghu18@gmail.com','payment'),
 ('Raghu','ragraghu18@gmail.com','payment');
/*!40000 ALTER TABLE `usercomplaints` ENABLE KEYS */;


--
-- Definition of table `volunteerapply`
--

DROP TABLE IF EXISTS `volunteerapply`;
CREATE TABLE `volunteerapply` (
  `name` varchar(50) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `document_type` varchar(50) DEFAULT NULL,
  `document` blob,
  `proofno` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `volunteerapply`
--

/*!40000 ALTER TABLE `volunteerapply` DISABLE KEYS */;
INSERT INTO `volunteerapply` (`name`,`dob`,`document_type`,`document`,`proofno`,`email`,`mobile`) VALUES 
 ('Likith','2023-07-18','id-card',0x6E756C6C,'22341','likiraghu18@gmail.com','9987564765');
/*!40000 ALTER TABLE `volunteerapply` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
